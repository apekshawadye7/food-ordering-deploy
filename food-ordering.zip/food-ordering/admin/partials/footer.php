<!-- Footer Section Starts -->
<div class="footer">
            <div class="wrapper">
                <p class="text-center">2020 All rights reserved, Food House. Developed By - <a href="#">Apeksha Wadye</a></p>
            </div>
        </div>
        <!-- Footer Section Ends -->

    </body>
</html>